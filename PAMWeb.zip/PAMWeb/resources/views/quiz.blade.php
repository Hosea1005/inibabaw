@extends('layout.main')

@section('title')
    <title>Result</title>
@endsection
<style>
    html, body {
        background-color: #fff;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 200;
        height: 100vh;
        margin: 0;
    }

    .full-height {
        height: 100vh;
    }

    .flex-center {
        align-items: center;
        display: flex;
        justify-content: center;
    }

    .position-ref {
        position: relative;
    }

    .top-right {
        position: absolute;
        right: 10px;
        top: 18px;
    }

    .content {
        text-align: center;
    }

    .title {
        font-size: 84px;
    }

    .links > a {
        color: #636b6f;
        padding: 0 25px;
        font-size: 13px;
        font-weight: 600;
        letter-spacing: .1rem;
        text-decoration: none;
        text-transform: uppercase;
    }

    .m-b-md {
        margin-bottom: 30px;
    }
</style>
@section('main-content')
<a href="{{ url('/quiz/create') }}" class="btn btn-success mb-1">Add</a>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID Quiz</th>
                        <th>Title</th>
                        <th>Duration</th>
                        <th colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($quiz as $p)
                    <tr>
                        <td>{{ $p->quiz_id }}</td>
                        <td>{{ $p->title }}</td>
                        <td>{{ $p->duration }}</td>
                        <td><a class="btn btn-primary" href="{{ url("quiz/{$p->quiz_id}/edit") }}">Edit</a></td>
                        <td><a href="/quiz/hapus/{{ $p->quiz_id }}">Delete</a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection