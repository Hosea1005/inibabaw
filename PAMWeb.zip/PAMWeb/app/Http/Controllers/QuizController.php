<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Quiz;
use Session;
use DB;

class QuizController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $quiz = DB::table('quiz')->get();
 
    	// mengirim data pegawai ke view index
    	return view('quiz',['quiz' => $quiz]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createquiz');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        DB::table('quiz')->insert([
            'title' => $request->input('title'),
            'duration' => $request->input('duration'),
        ]);
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $quiz = DB::table('quiz')->where('quiz_id',$id)->get();
	// passing data pegawai yang didapat ke view edit.blade.php
	    return view('editquiz',['quiz' => $quiz]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('quiz')->where('quiz_id',$request->id)->update([
		'title' => $request->title,
		'duration' => $request->duration
	]);
	// alihkan halaman ke halaman pegawai
	return redirect('/');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('quiz')->where('quiz_id',$id)->delete();
		
	// alihkan halaman ke halaman pegawai
	return redirect('/');
    }
}
