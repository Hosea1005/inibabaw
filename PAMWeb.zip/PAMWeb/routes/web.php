<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','QuizController@index');
Route::get('/quiz/create','QuizController@create');
// Route::get('/result/create','ResultController@create');
Route::post('/quiz','QuizController@store');
Route::get('/quiz/{id}/edit','QuizController@edit');
Route::get('/quiz/hapus/{id}','QuizController@destroy');

// Route::get('/', function () {
//     return view('quiz');
// });

Route::get('/test', function () {
    return view('test');
});

Route::post('/loginValidation', 'AuthController@login');
Route::get('/logout', 'AuthController@logout');
